DifficultyXP for Stolen Realm (BepInEx 5)

Makes experience gain scale with difficulty at the same rate as gold
(Classic +25%, Veteran +50%, Torturous +75%, Heart of the Realm +100%, Endless +25%).

REQUIRES BepInEx 5 already installed in the game folder (it is included in the DropRates install zip,
or get BepInEx_win_x64_5.4.23.x.zip from github.com/BepInEx/BepInEx/releases and extract it next to "Stolen Realm.exe").

INSTALL: extract this zip into your Stolen Realm game folder (the one containing "Stolen Realm.exe").
CONFIG:  BepInEx\config\stolenrealm.difficultyxp.cfg  (F11 in game reloads it)
UNINSTALL: delete BepInEx\plugins\DifficultyXP

Multiplayer: battle XP is decided by the HOST's copy of the mod; quest and event XP by each player's own copy.
