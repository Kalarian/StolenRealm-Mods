DropRates for Stolen Realm (BepInEx 5.4.23.5)

INSTALL: extract this zip into your Stolen Realm game folder (the one containing "Stolen Realm.exe"),
so that winhttp.dll and the BepInEx folder end up next to the exe.
Steam: right-click the game > Manage > Browse local files.

CONFIG: BepInEx\config\stolenrealm.droprates.cfg  (edit with Notepad; press F10 in game to apply)

UNINSTALL: delete winhttp.dll, doorstop_config.ini, .doorstop_version and the BepInEx folder.
Loot is rolled on your own PC, so this only changes your drops, whoever hosts.
